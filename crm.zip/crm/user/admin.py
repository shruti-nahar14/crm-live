from django.contrib import admin
from .models import Profile, Profileotp, lead

# Register your models here.
admin.site.register(lead)
admin.site.register(Profile)
admin.site.register(Profileotp)
