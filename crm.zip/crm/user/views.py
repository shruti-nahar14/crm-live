import http.client
from pickle import TRUE
import random
from django.shortcuts import render
from .models import *
from django.contrib import messages
from django.shortcuts import render,redirect
from django.http.response import HttpResponse
from django.contrib.auth  import authenticate,  login, logout
import uuid
from django.conf import settings
from django.core.mail import send_mail


def profile(request):
    return render(request,'user/page-profile.html')
    
def Insertrecord(request):
    firstname=request.POST.get('first_name') 
    lastname=request.POST.get('last_name') 
    username= request.POST.get('username') 
    email=request.POST.get('email') 
    mobno=request.POST.get('mob_no') 
    box=request.POST.get('box','off')
    password=request.POST.get('password')
    pass1=request.POST.get('pass1')
        
    
    if request.method=='POST':
            
             if request.POST.get('first_name') and request.POST.get('last_name') and request.POST.get('username') and request.POST.get('email') and request.POST.get('mob_no') and request.POST.get('password') and request.POST.get('pass1') and request.POST.get('box','off'):
                     if(len(mobno)==10):
                         
                          if (pass1== password) :
                                if(box=="on"):
                                    myuser = User.objects.create_user(email, username,password)
                                    myuser.save()
                                    myuser.first_name=firstname
                                    myuser.last_name=lastname
                                    myuser.mob_no=mobno
                                    myuser.pass1=pass1
                                    myuser.save()
                                    auth_token = str(uuid.uuid4())
                                    profile_obj = Profile.objects.create(user =myuser , auth_token = auth_token)
                                    profile_obj.save()
                                    send_mail_after_registration(email , auth_token)
                                    return render(request,'user/token_send.html')   
                                else:
                                      messages.warning(request,'Please Agree terms & condition ')
                                      return render(request,'user/index.html')
                          else:
                                     messages.warning(request, "Password not match ")
                                     return render(request,'user/index.html')
                     else:
                                     messages.warning(request, " Invalid Mobno ")
                                     return render(request,'user/index.html')
                        
    else:
        return render(request,'user/index.html')


def index(request):
    return render(request,'user/index.html')

def base(request):
    return render(request,'user/home.html')
def admin(request):
    return render(request,'user/admin.html')
def Teamlead(request):
    return render(request,'user/Teamlead.html')
def manager(request):
    return render(request,'user/manager.html')
def user(request):
    return render(request,'user/users.html')

def leads(request):
     name=request.POST.get('name') 
     email=request.POST.get('email') 
     mobno=request.POST.get('mob_no')
     password=request.POST.get('password')
     address=request.POST.get('address')
     state='Maharashtra'
     city=request.POST.get('city')
     
     if request.method=='POST':
          myuser =lead()
          myuser.email=email
          myuser.password=password
          myuser.save()
          myuser.name=name
          myuser.mob_no=mobno
          myuser.address=address
          myuser.state=state
          myuser.city=city
          myuser.save()
          return render(request,'user/users.html')   
    
                                
    

def Handlelogin(request):
    if request.method == 'POST':
        loginusername = request.POST.get('username1')
        loginpassword = request.POST.get('password1')
        field=request.POST.get('fieldname')
        if field == 'superadmin':
            loginusername.is_superadmin=TRUE
            
        user_obj = User.objects.filter(username = loginusername).first()
        if user_obj is None:
            messages.warning(request, 'User not found.')
            return render(request,'user/index.html')
        
        
        profile_obj = Profile.objects.filter(user = user_obj ).first()

        if not profile_obj.is_verified:
            messages.warning(request, 'Profile is not verified check your mail.')
            return render(request,'user/index.html')

        myusers=authenticate(username= loginusername, password= loginpassword)
        if myusers is not None and field=='superadmin':
            login(request, myusers)
            return redirect("base")
        elif myusers is not None and field=='Admin':
            login(request, myusers)
            return redirect("admin")
        elif myusers is not None and field=='Teamlead':
            login(request, myusers)
            return redirect("Teamlead")
        elif myusers is not None and field=='Manager':
            login(request, myusers)
            return redirect("manager")
        elif myusers is not None and field=='User':
            login(request, myusers)
            return redirect("user")
        else:
            messages.warning(request, "Invalid credentials! Please try again")
            return render(request,"user/index.html")
        
    return HttpResponse(request,"404- Not found")



def send_mail_after_registration(email , token):
    subject = 'Your accounts need to be verified'
    message = f'Hi paste the link to verify your account <a href="http://127.0.0.1:8000/user/verify/{token}">http://127.0.0.1:8000/user/verify/{token}</a>'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message , email_from ,recipient_list )
    
    
    
def verify(request , auth_token):
    try:
        profile_obj = Profile.objects.filter(auth_token = auth_token).first()
    

        if profile_obj:
            if profile_obj.is_verified:
                messages.success(request, 'Your account is already verified.')
                return render(request,'user/index.html')
            profile_obj.is_verified = True
            profile_obj.save()
            messages.success(request, 'Your account has been verified.')
            return render(request,'user/index.html')
        else:
            return render(request,'user/error.html')
    except Exception as e:
        return render(request,'user/home.html')
    
def send_otp(mobile , otp):
  
    conn = http.client.HTTPSConnection("api.azmobia.com")
    authkey = settings.AUTH_KEY 
    headers = { 'content-type': "application/json" }
    mess="Your otp is "+str(otp)
    url = "http://sms.azmobia.com/http-api.php?&username="+"magnum"+"&password="+"magnum@567"+"&mobile="+mobile+"&templateid="+"1707163915780037473"
    
    conn.request("GET", url , headers=headers)
    res = conn.getresponse()
    data = res.read()
    return None

def otp(request):
    #mobile = request.session['mobile']
    mobile=Profileotp.mobile
    context = {'mobile':mobile}
    if request.method=='get':
        otp = request.POST.get("otp")
        profile = Profileotp.objects.filter(mobile=mobile).first()
        if otp == Profileotp.otp:
             context = {'message' : ' OTP Verfied you can login ' , 'class' : 'success','mobile':mobile }
             return render(request,'user/home.html')
        else:
            context = {'message' : 'Wrong OTP' , 'class' : 'warning','mobile':mobile }
            return render(request,'user/otp.html' , context)
    return render(request,'user/otp.html' , context)   



def logout(request):
    messages.success(request, "Logout Successfully")
    return render(request,"user/index.html")
