from django.urls import path, include
from . import views

from django.contrib.auth import views as auth_views 
urlpatterns = [
    path("", views.index, name="index"),
     path("Insertrecord", views.Insertrecord, name="Insertrecord"),
     path('login', views.Handlelogin, name="login"),
     path('verify/login', views.Handlelogin, name="login"),
     path('reset/done/user/index', views.index, name="index"),
     path('profile',views.profile,name="profile"),
     path('verify/<auth_token>' , views.verify , name="verify"),
     path('base',views.base,name='base'),
     path('admin',views.admin,name='admin'),
     path('manager',views.manager,name='manager'),
     path('Teamlead',views.Teamlead,name='Teamlead'),
     path('user',views.user,name='user'),
     path('user/', include('django.contrib.auth.urls')),
     path('otp' , views.otp , name="otp"),
     path('otp/<otp>' , views.otp , name="otp"),
     path('base/logout',views.logout,name="logout"),
     path('leads',views.leads,name="leads"),
      #path('token' , views.token_send , name="token_send"),
    #path('success' , views.success , name='success'),
    path('password_reset/',auth_views.PasswordResetView.as_view(),name='password_reset'),
    path('password_reset/done/',auth_views.PasswordResetDoneView.as_view(),name='password_reset_done'),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(),name='password_reset_confirm'),
    path('reset/done/',auth_views.PasswordResetCompleteView.as_view(),name='password_reset_complete')
]